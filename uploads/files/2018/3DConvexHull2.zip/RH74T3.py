# This File is generated for Abaqus
# Author: Dongping Zhu
# Time: 2018-03-05
# Discription: Construct a convex hull in Abaqus

##### Function Define #####
def pointOnLine(point, lineA, lineB):
    vA = tuple(map(lambda x: x[0]-x[1], zip(lineA,point)))
    vB = tuple(map(lambda x: x[0]-x[1], zip(lineB,point)))
    lengthvA = 0.0
    lengthvB = 0.0
    dotMutli = 0.0
    for a,b in zip(vA,vB):
        lengthvA = lengthvA + a * a
        lengthvB = lengthvB + b * b
        dotMutli = dotMutli + a * b
    lengthvA = lengthvA ** 0.5
    lengthvB = lengthvB ** 0.5
    if abs(abs(dotMutli / (lengthvA * lengthvB)) - 1) < 1e-9 :
        return True
    else:
        return False
##### End Function Define #####

p = mdb.models['Model-1'].Part(name='Part-1', dimensionality=THREE_D, type=DEFORMABLE_BODY)
Point_1 = (-76.16881019335602,-23.30765483376878,-19.96844888444143)
Point_2 = (-100,100,19.15151605428542)
Point_3 = (-45.07871065025208,-25.75578649467332,25.69864120510763)
Point_4 = (-36.15175962393158,67.97234086291709,100)
Point_5 = (-100,-10.67672335047001,100)
Point_6 = (-95.8906758086255,-11.02987501952055,100)
Point_7 = (-100,100,100)
Point_8 = (-100,74.59507833448841,-23.04075888639284)
Point_9 = (-25.27642018872238,-13.46692138413839,22.41326880798799)
Point_10 = (-41.63297161277801,28.96287994433958,100)
Point_11 = (-69.52135227188043,40.83242231046374,-34.38086868411821)
Point_12 = (-17.56142051939491,-4.855236691481466,26.57845665042841)
Point_13 = (-100,-27.28709647691728,-19.13816814768516)
Point_14 = (-83.51365719501354,-28.45705123322072,-17.36751139133796)
Point_15 = (-11.8759531218644,24.11920158266416,22.46642186357282)
Point_16 = (-24.7469907913918,63.78296892854773,69.4492199130825)
Point_17 = (-49.30130033692677,100,93.56051221971089)
Point_18 = (-51.28787728983951,100,100)
Point_19 = (-100,9.123658113243934,-40.90378176243253)
Point_20 = (-87.7766942900363,11.01640521534814,-41.24095817282016)
p.WirePolyLine(points=((Point_2, Point_8)), mergeType = MERGE)
p.WirePolyLine(points=((Point_8, Point_11)), mergeType = MERGE)
p.WirePolyLine(points=((Point_11, Point_15)), mergeType = MERGE)
p.WirePolyLine(points=((Point_15, Point_16)), mergeType = MERGE)
p.WirePolyLine(points=((Point_16, Point_17)), mergeType = MERGE)
p.WirePolyLine(points=((Point_17, Point_2)), mergeType = MERGE)
eg=p.edges
egPointOn = []
for eachEdge in eg:
    egPointOn.append(eachEdge.pointOn[0])

seq = []
for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_2, Point_8)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_8, Point_11)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_11, Point_15)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_15, Point_16)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_16, Point_17)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_17, Point_2)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

p.CoverEdges(edgeList = seq, tryAnalytical=True)

p.WirePolyLine(points=((Point_2, Point_7)), mergeType = MERGE)
p.WirePolyLine(points=((Point_7, Point_5)), mergeType = MERGE)
p.WirePolyLine(points=((Point_5, Point_13)), mergeType = MERGE)
p.WirePolyLine(points=((Point_13, Point_19)), mergeType = MERGE)
p.WirePolyLine(points=((Point_19, Point_8)), mergeType = MERGE)
p.WirePolyLine(points=((Point_8, Point_2)), mergeType = MERGE)
eg=p.edges
egPointOn = []
for eachEdge in eg:
    egPointOn.append(eachEdge.pointOn[0])

seq = []
for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_2, Point_7)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_7, Point_5)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_5, Point_13)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_13, Point_19)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_19, Point_8)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_8, Point_2)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

p.CoverEdges(edgeList = seq, tryAnalytical=True)

p.WirePolyLine(points=((Point_2, Point_17)), mergeType = MERGE)
p.WirePolyLine(points=((Point_17, Point_18)), mergeType = MERGE)
p.WirePolyLine(points=((Point_18, Point_7)), mergeType = MERGE)
p.WirePolyLine(points=((Point_7, Point_2)), mergeType = MERGE)
eg=p.edges
egPointOn = []
for eachEdge in eg:
    egPointOn.append(eachEdge.pointOn[0])

seq = []
for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_2, Point_17)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_17, Point_18)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_18, Point_7)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_7, Point_2)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

p.CoverEdges(edgeList = seq, tryAnalytical=True)

p.WirePolyLine(points=((Point_3, Point_9)), mergeType = MERGE)
p.WirePolyLine(points=((Point_9, Point_1)), mergeType = MERGE)
p.WirePolyLine(points=((Point_1, Point_14)), mergeType = MERGE)
p.WirePolyLine(points=((Point_14, Point_3)), mergeType = MERGE)
eg=p.edges
egPointOn = []
for eachEdge in eg:
    egPointOn.append(eachEdge.pointOn[0])

seq = []
for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_3, Point_9)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_9, Point_1)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_1, Point_14)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_14, Point_3)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

p.CoverEdges(edgeList = seq, tryAnalytical=True)

p.WirePolyLine(points=((Point_3, Point_6)), mergeType = MERGE)
p.WirePolyLine(points=((Point_6, Point_10)), mergeType = MERGE)
p.WirePolyLine(points=((Point_10, Point_12)), mergeType = MERGE)
p.WirePolyLine(points=((Point_12, Point_9)), mergeType = MERGE)
p.WirePolyLine(points=((Point_9, Point_3)), mergeType = MERGE)
eg=p.edges
egPointOn = []
for eachEdge in eg:
    egPointOn.append(eachEdge.pointOn[0])

seq = []
for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_3, Point_6)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_6, Point_10)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_10, Point_12)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_12, Point_9)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_9, Point_3)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

p.CoverEdges(edgeList = seq, tryAnalytical=True)

p.WirePolyLine(points=((Point_3, Point_14)), mergeType = MERGE)
p.WirePolyLine(points=((Point_14, Point_13)), mergeType = MERGE)
p.WirePolyLine(points=((Point_13, Point_5)), mergeType = MERGE)
p.WirePolyLine(points=((Point_5, Point_6)), mergeType = MERGE)
p.WirePolyLine(points=((Point_6, Point_3)), mergeType = MERGE)
eg=p.edges
egPointOn = []
for eachEdge in eg:
    egPointOn.append(eachEdge.pointOn[0])

seq = []
for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_3, Point_14)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_14, Point_13)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_13, Point_5)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_5, Point_6)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_6, Point_3)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

p.CoverEdges(edgeList = seq, tryAnalytical=True)

p.WirePolyLine(points=((Point_4, Point_18)), mergeType = MERGE)
p.WirePolyLine(points=((Point_18, Point_17)), mergeType = MERGE)
p.WirePolyLine(points=((Point_17, Point_16)), mergeType = MERGE)
p.WirePolyLine(points=((Point_16, Point_4)), mergeType = MERGE)
eg=p.edges
egPointOn = []
for eachEdge in eg:
    egPointOn.append(eachEdge.pointOn[0])

seq = []
for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_4, Point_18)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_18, Point_17)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_17, Point_16)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_16, Point_4)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

p.CoverEdges(edgeList = seq, tryAnalytical=True)

p.WirePolyLine(points=((Point_4, Point_10)), mergeType = MERGE)
p.WirePolyLine(points=((Point_10, Point_6)), mergeType = MERGE)
p.WirePolyLine(points=((Point_6, Point_5)), mergeType = MERGE)
p.WirePolyLine(points=((Point_5, Point_7)), mergeType = MERGE)
p.WirePolyLine(points=((Point_7, Point_18)), mergeType = MERGE)
p.WirePolyLine(points=((Point_18, Point_4)), mergeType = MERGE)
eg=p.edges
egPointOn = []
for eachEdge in eg:
    egPointOn.append(eachEdge.pointOn[0])

seq = []
for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_4, Point_10)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_10, Point_6)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_6, Point_5)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_5, Point_7)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_7, Point_18)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_18, Point_4)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

p.CoverEdges(edgeList = seq, tryAnalytical=True)

p.WirePolyLine(points=((Point_4, Point_16)), mergeType = MERGE)
p.WirePolyLine(points=((Point_16, Point_15)), mergeType = MERGE)
p.WirePolyLine(points=((Point_15, Point_12)), mergeType = MERGE)
p.WirePolyLine(points=((Point_12, Point_10)), mergeType = MERGE)
p.WirePolyLine(points=((Point_10, Point_4)), mergeType = MERGE)
eg=p.edges
egPointOn = []
for eachEdge in eg:
    egPointOn.append(eachEdge.pointOn[0])

seq = []
for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_4, Point_16)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_16, Point_15)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_15, Point_12)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_12, Point_10)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_10, Point_4)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

p.CoverEdges(edgeList = seq, tryAnalytical=True)

p.WirePolyLine(points=((Point_8, Point_19)), mergeType = MERGE)
p.WirePolyLine(points=((Point_19, Point_20)), mergeType = MERGE)
p.WirePolyLine(points=((Point_20, Point_11)), mergeType = MERGE)
p.WirePolyLine(points=((Point_11, Point_8)), mergeType = MERGE)
eg=p.edges
egPointOn = []
for eachEdge in eg:
    egPointOn.append(eachEdge.pointOn[0])

seq = []
for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_8, Point_19)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_19, Point_20)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_20, Point_11)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_11, Point_8)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

p.CoverEdges(edgeList = seq, tryAnalytical=True)

p.WirePolyLine(points=((Point_9, Point_12)), mergeType = MERGE)
p.WirePolyLine(points=((Point_12, Point_15)), mergeType = MERGE)
p.WirePolyLine(points=((Point_15, Point_11)), mergeType = MERGE)
p.WirePolyLine(points=((Point_11, Point_20)), mergeType = MERGE)
p.WirePolyLine(points=((Point_20, Point_1)), mergeType = MERGE)
p.WirePolyLine(points=((Point_1, Point_9)), mergeType = MERGE)
eg=p.edges
egPointOn = []
for eachEdge in eg:
    egPointOn.append(eachEdge.pointOn[0])

seq = []
for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_9, Point_12)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_12, Point_15)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_15, Point_11)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_11, Point_20)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_20, Point_1)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_1, Point_9)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

p.CoverEdges(edgeList = seq, tryAnalytical=True)

p.WirePolyLine(points=((Point_13, Point_14)), mergeType = MERGE)
p.WirePolyLine(points=((Point_14, Point_1)), mergeType = MERGE)
p.WirePolyLine(points=((Point_1, Point_20)), mergeType = MERGE)
p.WirePolyLine(points=((Point_20, Point_19)), mergeType = MERGE)
p.WirePolyLine(points=((Point_19, Point_13)), mergeType = MERGE)
eg=p.edges
egPointOn = []
for eachEdge in eg:
    egPointOn.append(eachEdge.pointOn[0])

seq = []
for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_13, Point_14)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_14, Point_1)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_1, Point_20)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_20, Point_19)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

for eachEgPointOn in egPointOn:
    if(pointOnLine(eachEgPointOn, Point_19, Point_13)):
        seq.append(eg[egPointOn.index(eachEgPointOn)])

p.CoverEdges(edgeList = seq, tryAnalytical=True)

f = p.faces
p.AddCells(faceList = f[:])
